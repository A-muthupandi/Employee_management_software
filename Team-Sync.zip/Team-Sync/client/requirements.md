## Packages
recharts | For the performance analytics chart on the dashboard
framer-motion | For smooth animations and transitions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
