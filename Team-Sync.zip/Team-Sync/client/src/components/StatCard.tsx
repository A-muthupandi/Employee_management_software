import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  trendUp?: boolean;
  color?: "primary" | "secondary" | "accent" | "green" | "orange";
  loading?: boolean;
}

export function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  trend, 
  trendUp, 
  color = "primary",
  loading = false
}: StatCardProps) {
  
  const colorStyles = {
    primary: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
    secondary: "bg-slate-500/10 text-slate-600 dark:text-slate-400",
    accent: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
    green: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    orange: "bg-orange-500/10 text-orange-600 dark:text-orange-400",
  };

  return (
    <div className="glass-card rounded-2xl p-6 relative overflow-hidden group">
      {/* Background decoration */}
      <div className={cn(
        "absolute -right-6 -top-6 w-24 h-24 rounded-full opacity-0 group-hover:opacity-20 transition-opacity duration-500 blur-2xl",
        color === "primary" && "bg-blue-500",
        color === "secondary" && "bg-slate-500",
        color === "accent" && "bg-purple-500",
        color === "green" && "bg-emerald-500",
        color === "orange" && "bg-orange-500",
      )} />

      <div className="flex justify-between items-start relative z-10">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
          {loading ? (
            <div className="h-8 w-24 bg-muted animate-pulse rounded-md" />
          ) : (
            <h3 className="text-3xl font-display font-bold text-foreground tracking-tight">{value}</h3>
          )}
          
          {trend && (
            <div className={cn(
              "flex items-center gap-1 mt-2 text-xs font-medium",
              trendUp ? "text-emerald-600" : "text-rose-600"
            )}>
              <span>{trend}</span>
              <span>vs last month</span>
            </div>
          )}
        </div>
        
        <div className={cn("p-3 rounded-xl", colorStyles[color])}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
    </div>
  );
}
