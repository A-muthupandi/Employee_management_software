import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loader2 } from "lucide-react";
import { ReactNode } from "react";

interface Column<T> {
  header: string;
  accessorKey?: keyof T;
  cell?: (item: T) => ReactNode;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  loading?: boolean;
  onRowClick?: (item: T) => void;
  emptyMessage?: string;
}

export function DataTable<T extends { id: number | string }>({ 
  data, 
  columns, 
  loading, 
  onRowClick,
  emptyMessage = "No records found"
}: DataTableProps<T>) {
  
  if (loading) {
    return (
      <div className="w-full h-64 flex flex-col items-center justify-center text-muted-foreground glass-panel rounded-2xl">
        <Loader2 className="h-8 w-8 animate-spin mb-4 text-primary" />
        <p>Loading data...</p>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="w-full h-64 flex items-center justify-center text-muted-foreground glass-panel rounded-2xl border-dashed">
        <p>{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border/50 overflow-hidden glass-panel shadow-sm">
      <Table>
        <TableHeader className="bg-muted/50">
          <TableRow className="hover:bg-transparent border-border/50">
            {columns.map((col, i) => (
              <TableHead key={i} className="h-12 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                {col.header}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((row) => (
            <TableRow 
              key={row.id} 
              className={`
                border-border/50 transition-colors hover:bg-muted/30
                ${onRowClick ? 'cursor-pointer' : ''}
              `}
              onClick={() => onRowClick && onRowClick(row)}
            >
              {columns.map((col, i) => (
                <TableCell key={i} className="py-4 font-medium">
                  {col.cell 
                    ? col.cell(row) 
                    : col.accessorKey 
                      ? String(row[col.accessorKey]) 
                      : null
                  }
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
