import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useAttendance(userId?: number) {
  return useQuery({
    queryKey: [api.attendance.list.path, userId],
    queryFn: async () => {
      const url = userId 
        ? `${api.attendance.list.path}?userId=${userId}` 
        : api.attendance.list.path;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch attendance");
      return api.attendance.list.responses[200].parse(await res.json());
    },
  });
}

export function useCheckIn() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.attendance.checkIn.path, {
        method: api.attendance.checkIn.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Check-in failed");
      return api.attendance.checkIn.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.attendance.list.path] });
    },
  });
}

export function useCheckOut() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.attendance.checkOut.path, {
        method: api.attendance.checkOut.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Check-out failed");
      return api.attendance.checkOut.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.attendance.list.path] });
    },
  });
}
