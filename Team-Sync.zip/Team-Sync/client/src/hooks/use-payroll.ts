import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertPayroll } from "@shared/routes";
import { z } from "zod";

type InsertPayrollData = z.infer<typeof api.payroll.create.input>;

export function usePayroll(userId?: number) {
  return useQuery({
    queryKey: [api.payroll.list.path, userId],
    queryFn: async () => {
      const url = userId 
        ? `${api.payroll.list.path}?userId=${userId}` 
        : api.payroll.list.path;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch payroll");
      return api.payroll.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreatePayroll() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertPayrollData) => {
      const res = await fetch(api.payroll.create.path, {
        method: api.payroll.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to generate payroll");
      return api.payroll.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.payroll.list.path] });
    },
  });
}
