import { useAttendance, useCheckIn, useCheckOut } from "@/hooks/use-attendance";
import { DataTable } from "@/components/DataTable";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { format } from "date-fns";
import { LogIn, LogOut, Clock, CalendarDays } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Attendance() {
  const { data: attendanceHistory, isLoading } = useAttendance();
  const checkIn = useCheckIn();
  const checkOut = useCheckOut();
  const { toast } = useToast();

  const today = new Date();
  // Simple logic to check if user has checked in today (in a real app, backend would tell us current status)
  const todayRecord = attendanceHistory?.find(r => r.date === format(today, 'yyyy-MM-dd'));
  const isCheckedIn = !!todayRecord?.checkIn && !todayRecord?.checkOut;
  const hasCheckedOut = !!todayRecord?.checkOut;

  const handleCheckIn = async () => {
    try {
      await checkIn.mutateAsync();
      toast({ title: "Checked In", description: "You have successfully checked in for the day." });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Error", description: err.message });
    }
  };

  const handleCheckOut = async () => {
    try {
      await checkOut.mutateAsync();
      toast({ title: "Checked Out", description: "Have a great evening!" });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Error", description: err.message });
    }
  };

  const columns = [
    {
      header: "Date",
      cell: (record: any) => format(new Date(record.date), "MMM dd, yyyy"),
    },
    {
      header: "Check In",
      cell: (record: any) => record.checkIn ? format(new Date(record.checkIn), "hh:mm a") : "-",
    },
    {
      header: "Check Out",
      cell: (record: any) => record.checkOut ? format(new Date(record.checkOut), "hh:mm a") : "-",
    },
    {
      header: "Status",
      cell: (record: any) => (
        <span className={`
          px-2 py-1 rounded-md text-xs font-semibold capitalize
          ${record.status === 'present' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : ''}
          ${record.status === 'absent' ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400' : ''}
          ${record.status === 'half_day' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400' : ''}
        `}>
          {record.status.replace('_', ' ')}
        </span>
      ),
    },
    {
      header: "Hours",
      cell: (record: any) => {
        if (!record.checkIn || !record.checkOut) return "-";
        const diff = new Date(record.checkOut).getTime() - new Date(record.checkIn).getTime();
        const hours = diff / (1000 * 60 * 60);
        return `${hours.toFixed(1)} hrs`;
      }
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h2 className="text-3xl font-display font-bold tracking-tight">Attendance</h2>
        <p className="text-muted-foreground mt-1">Track your daily work hours</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          {/* Main Action Card */}
          <div className="glass-card rounded-2xl p-8 flex flex-col items-center justify-center text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary to-accent" />
            
            <div className="mb-6">
              <h3 className="text-5xl font-mono font-bold text-foreground mb-2">
                {format(today, "hh:mm a")}
              </h3>
              <p className="text-muted-foreground">{format(today, "EEEE, MMMM do, yyyy")}</p>
            </div>

            <div className="flex gap-4">
              {!isCheckedIn && !hasCheckedOut && (
                <Button 
                  size="lg" 
                  onClick={handleCheckIn} 
                  disabled={checkIn.isPending}
                  className="h-16 px-8 text-lg rounded-xl shadow-lg shadow-primary/25 hover:scale-105 transition-transform"
                >
                  <LogIn className="mr-2 h-6 w-6" />
                  Check In
                </Button>
              )}
              
              {isCheckedIn && (
                <Button 
                  size="lg" 
                  variant="destructive"
                  onClick={handleCheckOut}
                  disabled={checkOut.isPending}
                  className="h-16 px-8 text-lg rounded-xl shadow-lg shadow-destructive/25 hover:scale-105 transition-transform"
                >
                  <LogOut className="mr-2 h-6 w-6" />
                  Check Out
                </Button>
              )}

              {hasCheckedOut && (
                <div className="bg-emerald-500/10 text-emerald-600 px-6 py-4 rounded-xl border border-emerald-500/20 font-medium flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Day Completed
                </div>
              )}
            </div>
          </div>

          <DataTable 
            data={attendanceHistory || []} 
            columns={columns} 
            loading={isLoading}
            emptyMessage="No attendance records found" 
          />
        </div>

        <div className="space-y-6">
          <Card className="glass-panel border-none shadow-none bg-primary/5">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <CalendarDays className="h-5 w-5 text-primary" />
                Monthly Summary
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Present Days</span>
                  <span className="font-bold">18</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Absent</span>
                  <span className="font-bold text-destructive">1</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Late Arrivals</span>
                  <span className="font-bold text-orange-500">2</span>
                </div>
                <div className="h-px bg-border/50 my-2" />
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Total Hours</span>
                  <span className="font-bold text-primary">142.5 hrs</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="glass-panel border-none shadow-none bg-orange-500/5">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">Upcoming Holidays</h3>
              <ul className="space-y-3 text-sm">
                <li className="flex justify-between">
                  <span className="text-muted-foreground">Labor Day</span>
                  <span className="font-medium">May 1</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-muted-foreground">Eid al-Fitr</span>
                  <span className="font-medium">Apr 10</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
