import { useDashboardStats } from "@/hooks/use-stats";
import { StatCard } from "@/components/StatCard";
import { Users, UserCheck, Clock, UserMinus, Activity } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard() {
  const { data: stats, isLoading } = useDashboardStats();

  // Mock data for the chart - in a real app this would come from the API
  const chartData = [
    { name: 'Mon', performance: 65, attendance: 85 },
    { name: 'Tue', performance: 75, attendance: 88 },
    { name: 'Wed', performance: 85, attendance: 92 },
    { name: 'Thu', performance: 70, attendance: 85 },
    { name: 'Fri', performance: 80, attendance: 90 },
    { name: 'Sat', performance: 60, attendance: 40 },
    { name: 'Sun', performance: 50, attendance: 35 },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div>
        <h2 className="text-3xl font-display font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground mt-1">Overview of your company's performance</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Employees"
          value={stats?.totalEmployees || 0}
          icon={Users}
          loading={isLoading}
          color="primary"
          trend="+12%"
          trendUp={true}
        />
        <StatCard
          title="Active Now"
          value={stats?.activeEmployees || 0}
          icon={UserCheck}
          loading={isLoading}
          color="green"
          trend="+5%"
          trendUp={true}
        />
        <StatCard
          title="On Leave"
          value={stats?.onLeaveEmployees || 0}
          icon={UserMinus}
          loading={isLoading}
          color="orange"
          trend="-2%"
          trendUp={false}
        />
        <StatCard
          title="Pending Approval"
          value={stats?.pendingEmployees || 0}
          icon={Clock}
          loading={isLoading}
          color="accent"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Main Chart */}
        <div className="md:col-span-2 glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Performance Analytics</h3>
              <p className="text-sm text-muted-foreground">Weekly attendance & performance trends</p>
            </div>
            <div className="p-2 bg-primary/10 rounded-lg text-primary">
              <Activity className="h-5 w-5" />
            </div>
          </div>
          
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorPerf" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorAtt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} 
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    borderRadius: '12px', 
                    border: '1px solid hsl(var(--border))',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)' 
                  }}
                  itemStyle={{ color: 'hsl(var(--foreground))' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="performance" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorPerf)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="attendance" 
                  stroke="hsl(var(--accent))" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorAtt)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Activity / Tasks Overview */}
        <div className="glass-card rounded-2xl p-6">
          <h3 className="text-lg font-semibold mb-4">Quick Stats</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-xl bg-background/50 border border-border/50">
              <span className="text-sm font-medium">Avg. Attendance</span>
              <span className="text-sm font-bold text-emerald-600">92%</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-background/50 border border-border/50">
              <span className="text-sm font-medium">On-Time Arrival</span>
              <span className="text-sm font-bold text-blue-600">88%</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-background/50 border border-border/50">
              <span className="text-sm font-medium">Tasks Completed</span>
              <span className="text-sm font-bold text-purple-600">145</span>
            </div>
            
            <div className="mt-8 pt-6 border-t border-border/50">
              <h4 className="text-sm font-semibold mb-3">Department Headcount</h4>
              <div className="space-y-3">
                <div className="flex justify-between text-xs">
                  <span>Engineering</span>
                  <span className="font-mono text-muted-foreground">12</span>
                </div>
                <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary w-[70%] rounded-full" />
                </div>
                
                <div className="flex justify-between text-xs pt-1">
                  <span>HR & Admin</span>
                  <span className="font-mono text-muted-foreground">4</span>
                </div>
                <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-accent w-[30%] rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
