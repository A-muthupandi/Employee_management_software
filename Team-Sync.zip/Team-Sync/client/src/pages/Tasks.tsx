import { useTasks, useCreateTask, useUpdateTask } from "@/hooks/use-tasks";
import { useEmployees } from "@/hooks/use-employees";
import { Button } from "@/components/ui/button";
import { Plus, CheckCircle2, Circle, Clock } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { api, type InsertTask } from "@shared/routes";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

const formSchema = api.tasks.create.input;

export default function Tasks() {
  const { data: tasks, isLoading } = useTasks();
  const [isOpen, setIsOpen] = useState(false);
  
  const pendingTasks = tasks?.filter(t => t.status === 'pending') || [];
  const inProgressTasks = tasks?.filter(t => t.status === 'in_progress') || [];
  const completedTasks = tasks?.filter(t => t.status === 'completed') || [];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-display font-bold tracking-tight">Task Board</h2>
          <p className="text-muted-foreground mt-1">Manage assignments and track progress</p>
        </div>
        
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="rounded-xl shadow-lg shadow-primary/20">
              <Plus className="mr-2 h-4 w-4" />
              New Task
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Task</DialogTitle>
            </DialogHeader>
            <TaskForm onSuccess={() => setIsOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-3 gap-6 h-full min-h-[500px]">
        <TaskColumn title="To Do" icon={Circle} tasks={pendingTasks} color="slate" />
        <TaskColumn title="In Progress" icon={Clock} tasks={inProgressTasks} color="blue" />
        <TaskColumn title="Completed" icon={CheckCircle2} tasks={completedTasks} color="emerald" />
      </div>
    </div>
  );
}

function TaskColumn({ title, icon: Icon, tasks, color }: { title: string, icon: any, tasks: any[], color: string }) {
  const colorStyles = {
    slate: "bg-slate-50 border-slate-200 dark:bg-slate-900/50 dark:border-slate-800",
    blue: "bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800",
    emerald: "bg-emerald-50 border-emerald-200 dark:bg-emerald-900/20 dark:border-emerald-800",
  };

  return (
    <div className={`flex flex-col h-full rounded-2xl border p-4 ${colorStyles[color as keyof typeof colorStyles]}`}>
      <div className="flex items-center gap-2 mb-4">
        <Icon className="h-5 w-5 opacity-70" />
        <h3 className="font-bold text-sm uppercase tracking-wider opacity-70">{title}</h3>
        <span className="ml-auto bg-background/50 px-2 py-0.5 rounded-full text-xs font-bold">{tasks.length}</span>
      </div>
      
      <div className="space-y-3 flex-1 overflow-y-auto">
        {tasks.map(task => (
          <TaskCard key={task.id} task={task} />
        ))}
      </div>
    </div>
  );
}

function TaskCard({ task }: { task: any }) {
  const updateMutation = useUpdateTask();

  const handleStatusChange = () => {
    let newStatus = 'pending';
    if (task.status === 'pending') newStatus = 'in_progress';
    else if (task.status === 'in_progress') newStatus = 'completed';
    
    if (newStatus !== task.status) {
      updateMutation.mutate({ id: task.id, status: newStatus });
    }
  };

  return (
    <div className="bg-background border border-border/50 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer group relative">
      <div className="flex justify-between items-start mb-2">
        <Badge variant="outline" className={`
          ${task.priority === 'high' ? 'text-red-600 border-red-200 bg-red-50' : ''}
          ${task.priority === 'medium' ? 'text-orange-600 border-orange-200 bg-orange-50' : ''}
          ${task.priority === 'low' ? 'text-blue-600 border-blue-200 bg-blue-50' : ''}
        `}>
          {task.priority}
        </Badge>
        {task.kpiPoints > 0 && (
          <span className="text-xs font-bold text-primary">+{task.kpiPoints} KPI</span>
        )}
      </div>
      
      <h4 className="font-semibold mb-1">{task.title}</h4>
      <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{task.description}</p>
      
      <div className="flex items-center justify-between text-xs text-muted-foreground border-t border-border/50 pt-3 mt-3">
        <span>Due: {task.dueDate ? format(new Date(task.dueDate), "MMM d") : "No date"}</span>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-6 px-2 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => { e.stopPropagation(); handleStatusChange(); }}
        >
          Advance →
        </Button>
      </div>
    </div>
  );
}

function TaskForm({ onSuccess }: { onSuccess: () => void }) {
  const { toast } = useToast();
  const createMutation = useCreateTask();
  const { data: employees } = useEmployees();
  const { user } = useAuth();

  const form = useForm<InsertTask>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      assignedTo: 0,
      assignedBy: user?.id || 0,
      status: "pending",
      priority: "medium",
      kpiPoints: 10,
    },
  });

  async function onSubmit(values: InsertTask) {
    try {
      await createMutation.mutateAsync({ ...values, assignedBy: user?.id || 0 });
      toast({ title: "Success", description: "Task created successfully" });
      onSuccess();
    } catch (error: any) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Title</FormLabel>
              <FormControl><Input placeholder="Task title" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl><Textarea placeholder="Details..." {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="assignedTo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Assign To</FormLabel>
                <Select onValueChange={(val) => field.onChange(Number(val))}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select user" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {employees?.map((emp) => (
                      <SelectItem key={emp.id} value={String(emp.id)}>
                        {emp.fullName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="priority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Priority</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value || "medium"}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="dueDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Due Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} value={field.value ? String(field.value) : ""} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="kpiPoints"
            render={({ field }) => (
              <FormItem>
                <FormLabel>KPI Points</FormLabel>
                <FormControl>
                  <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button type="submit" className="w-full" disabled={createMutation.isPending}>
          Create Task
        </Button>
      </form>
    </Form>
  );
}
