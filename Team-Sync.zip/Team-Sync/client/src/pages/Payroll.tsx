import { usePayroll, useCreatePayroll } from "@/hooks/use-payroll";
import { useEmployees } from "@/hooks/use-employees";
import { DataTable } from "@/components/DataTable";
import { Button } from "@/components/ui/button";
import { DollarSign, Download, Plus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { api, type InsertPayroll } from "@shared/routes";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const formSchema = api.payroll.create.input;

export default function Payroll() {
  const { data: payrolls, isLoading } = usePayroll();
  const [isOpen, setIsOpen] = useState(false);

  const columns = [
    {
      header: "Employee",
      accessorKey: "userId",
      cell: (row: any) => row.user ? row.user.fullName : `User #${row.userId}`,
    },
    {
      header: "Month/Year",
      cell: (row: any) => `${row.month} ${row.year}`,
    },
    {
      header: "Basic Salary",
      cell: (row: any) => `$${Number(row.basicSalary).toLocaleString()}`,
    },
    {
      header: "Net Pay",
      cell: (row: any) => (
        <span className="font-bold text-emerald-600">
          ${Number(row.netPay).toLocaleString()}
        </span>
      ),
    },
    {
      header: "Status",
      cell: (row: any) => (
        <span className={`
          px-2 py-1 rounded-full text-xs font-semibold
          ${row.status === 'paid' ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'}
        `}>
          {row.status}
        </span>
      ),
    },
    {
      header: "Action",
      cell: () => (
        <Button variant="ghost" size="sm">
          <Download className="h-4 w-4" />
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-display font-bold tracking-tight">Payroll</h2>
          <p className="text-muted-foreground mt-1">Manage salaries and payslips</p>
        </div>

        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="rounded-xl shadow-lg shadow-primary/20">
              <Plus className="mr-2 h-4 w-4" />
              Generate Payslip
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Generate Payslip</DialogTitle>
            </DialogHeader>
            <PayrollForm onSuccess={() => setIsOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-3 mb-8">
        <div className="glass-card p-6 rounded-2xl">
          <h3 className="text-sm font-medium text-muted-foreground mb-2">Total Payroll Cost</h3>
          <p className="text-3xl font-bold font-display">$142,500</p>
          <p className="text-xs text-muted-foreground mt-1">For current month</p>
        </div>
        <div className="glass-card p-6 rounded-2xl">
          <h3 className="text-sm font-medium text-muted-foreground mb-2">Pending Payments</h3>
          <p className="text-3xl font-bold font-display text-orange-600">12</p>
          <p className="text-xs text-muted-foreground mt-1">Employees yet to be paid</p>
        </div>
      </div>

      <DataTable 
        data={payrolls || []} 
        columns={columns} 
        loading={isLoading}
        emptyMessage="No payroll records generated yet" 
      />
    </div>
  );
}

function PayrollForm({ onSuccess }: { onSuccess: () => void }) {
  const { toast } = useToast();
  const createMutation = useCreatePayroll();
  const { data: employees } = useEmployees();

  const form = useForm<InsertPayroll>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      userId: 0,
      month: "October",
      year: new Date().getFullYear(),
      basicSalary: "5000",
      bonuses: "0",
      deductions: "0",
      netPay: "5000",
      status: "pending",
    },
  });

  // Auto-calculate net pay
  const calculateNet = () => {
    const basic = Number(form.getValues("basicSalary")) || 0;
    const bonus = Number(form.getValues("bonuses")) || 0;
    const deduct = Number(form.getValues("deductions")) || 0;
    form.setValue("netPay", String(basic + bonus - deduct));
  };

  async function onSubmit(values: InsertPayroll) {
    try {
      await createMutation.mutateAsync(values);
      toast({ title: "Success", description: "Payslip generated successfully" });
      onSuccess();
    } catch (error: any) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="userId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Employee</FormLabel>
              <Select onValueChange={(val) => field.onChange(Number(val))}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {employees?.map((emp) => (
                    <SelectItem key={emp.id} value={String(emp.id)}>
                      {emp.fullName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="month"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Month</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Month" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {['January','February','March','April','May','June','July','August','September','October','November','December'].map(m => (
                      <SelectItem key={m} value={m}>{m}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="year"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Year</FormLabel>
                <FormControl><Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="basicSalary"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Basic</FormLabel>
                <FormControl><Input {...field} onChange={e => { field.onChange(e); calculateNet(); }} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="bonuses"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bonus</FormLabel>
                <FormControl><Input {...field} onChange={e => { field.onChange(e); calculateNet(); }} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="deductions"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Deduction</FormLabel>
                <FormControl><Input {...field} onChange={e => { field.onChange(e); calculateNet(); }} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="netPay"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Net Pay</FormLabel>
              <FormControl><Input {...field} readOnly className="bg-muted font-bold" /></FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={createMutation.isPending}>
          {createMutation.isPending ? "Generating..." : "Generate Payslip"}
        </Button>
      </form>
    </Form>
  );
}
