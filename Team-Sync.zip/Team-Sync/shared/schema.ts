import { pgTable, text, serial, integer, boolean, timestamp, decimal, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: ["admin", "hr", "employee"] }).notNull().default("employee"),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  department: text("department").notNull(),
  jobTitle: text("job_title").notNull(),
  status: text("status", { enum: ["active", "on_leave", "pending"] }).notNull().default("active"),
  photoUrl: text("photo_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: date("date").notNull(), // stored as YYYY-MM-DD
  checkIn: timestamp("check_in"),
  checkOut: timestamp("check_out"),
  status: text("status", { enum: ["present", "absent", "half_day"] }).default("present"),
});

export const payroll = pgTable("payroll", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  month: text("month").notNull(), // e.g., "January"
  year: integer("year").notNull(),
  basicSalary: decimal("basic_salary").notNull(),
  bonuses: decimal("bonuses").default("0"),
  deductions: decimal("deductions").default("0"),
  netPay: decimal("net_pay").notNull(),
  status: text("status", { enum: ["pending", "paid"] }).default("pending"),
  generatedAt: timestamp("generated_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  assignedTo: integer("assigned_to").notNull(),
  assignedBy: integer("assigned_by").notNull(),
  status: text("status", { enum: ["pending", "in_progress", "completed"] }).default("pending"),
  priority: text("priority", { enum: ["low", "medium", "high"] }).default("medium"),
  dueDate: timestamp("due_date"),
  kpiPoints: integer("kpi_points").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  attendance: many(attendance),
  payroll: many(payroll),
  tasksAssigned: many(tasks, { relationName: "assignedTo" }),
  tasksCreated: many(tasks, { relationName: "assignedBy" }),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  user: one(users, {
    fields: [attendance.userId],
    references: [users.id],
  }),
}));

export const payrollRelations = relations(payroll, ({ one }) => ({
  user: one(users, {
    fields: [payroll.userId],
    references: [users.id],
  }),
}));

export const tasksRelations = relations(tasks, ({ one }) => ({
  assignee: one(users, {
    fields: [tasks.assignedTo],
    references: [users.id],
    relationName: "assignedTo",
  }),
  creator: one(users, {
    fields: [tasks.assignedBy],
    references: [users.id],
    relationName: "assignedBy",
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true });
export const insertPayrollSchema = createInsertSchema(payroll).omit({ id: true, generatedAt: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, createdAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Attendance = typeof attendance.$inferSelect;
export type Payroll = typeof payroll.$inferSelect;
export type Task = typeof tasks.$inferSelect;
