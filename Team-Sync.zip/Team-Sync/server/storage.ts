import { db } from "./db";
import {
  users, attendance, payroll, tasks,
  type User, type InsertUser,
  type Attendance, type InsertUser as InsertAttendance, // Re-map for clarity if needed, but schema uses InsertUser type name from zod
  type Payroll, type Task,
} from "@shared/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Auth & Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;
  listUsers(filters?: any): Promise<User[]>;
  getEmployeeStats(): Promise<{ total: number; active: number; onLeave: number; pending: number }>;
  
  // Attendance
  getAttendance(userId: number, date: string): Promise<Attendance | undefined>;
  checkIn(userId: number): Promise<Attendance>;
  checkOut(attendanceId: number): Promise<Attendance>;
  listAttendance(userId?: number): Promise<Attendance[]>;

  // Payroll
  createPayroll(payroll: any): Promise<Payroll>;
  listPayroll(userId?: number): Promise<Payroll[]>;

  // Tasks
  createTask(task: any): Promise<Task>;
  updateTask(id: number, task: any): Promise<Task>;
  listTasks(filters?: any): Promise<Task[]>;
  
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async listUsers(filters?: any): Promise<User[]> {
    let query = db.select().from(users);
    const conditions = [];
    
    if (filters?.role) conditions.push(eq(users.role, filters.role));
    if (filters?.department) conditions.push(eq(users.department, filters.department));
    if (filters?.status) conditions.push(eq(users.status, filters.status));
    
    if (conditions.length > 0) {
      // @ts-ignore
      query = query.where(and(...conditions));
    }
    
    return await query;
  }

  async getEmployeeStats() {
    const all = await db.select().from(users);
    return {
      total: all.length,
      active: all.filter(u => u.status === 'active').length,
      onLeave: all.filter(u => u.status === 'on_leave').length,
      pending: all.filter(u => u.status === 'pending').length,
    };
  }

  // Attendance
  async getAttendance(userId: number, date: string): Promise<Attendance | undefined> {
    const [record] = await db.select().from(attendance)
      .where(and(eq(attendance.userId, userId), eq(attendance.date, date)));
    return record;
  }

  async checkIn(userId: number): Promise<Attendance> {
    const today = new Date().toISOString().split('T')[0];
    const [record] = await db.insert(attendance).values({
      userId,
      date: today,
      checkIn: new Date(),
      status: 'present'
    }).returning();
    return record;
  }

  async checkOut(attendanceId: number): Promise<Attendance> {
    const [record] = await db.update(attendance)
      .set({ checkOut: new Date() })
      .where(eq(attendance.id, attendanceId))
      .returning();
    return record;
  }

  async listAttendance(userId?: number): Promise<Attendance[]> {
    if (userId) {
      return await db.select().from(attendance).where(eq(attendance.userId, userId)).orderBy(desc(attendance.date));
    }
    return await db.select().from(attendance).orderBy(desc(attendance.date));
  }

  // Payroll
  async createPayroll(entry: any): Promise<Payroll> {
    const [record] = await db.insert(payroll).values(entry).returning();
    return record;
  }

  async listPayroll(userId?: number): Promise<Payroll[]> {
    if (userId) {
      return await db.select().from(payroll).where(eq(payroll.userId, userId));
    }
    return await db.select().from(payroll);
  }

  // Tasks
  async createTask(entry: any): Promise<Task> {
    const [record] = await db.insert(tasks).values(entry).returning();
    return record;
  }

  async updateTask(id: number, updates: any): Promise<Task> {
    const [record] = await db.update(tasks).set(updates).where(eq(tasks.id, id)).returning();
    return record;
  }

  async listTasks(filters?: any): Promise<Task[]> {
    let query = db.select().from(tasks);
    if (filters?.assignedTo) {
      query = query.where(eq(tasks.assignedTo, filters.assignedTo));
    }
    return await query.orderBy(desc(tasks.createdAt));
  }
}

export const storage = new DatabaseStorage();
