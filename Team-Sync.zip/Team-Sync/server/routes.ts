import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // Setup Authentication (Passport)
  setupAuth(app);

  // === Users ===
  app.get(api.users.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const users = await storage.listUsers(req.query);
    res.json(users);
  });

  app.get(api.users.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = await storage.getUser(Number(req.params.id));
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  });

  app.post(api.users.create.path, async (req, res) => {
    // In real app, restrict to Admin
    try {
      const input = api.users.create.input.parse(req.body);
      const user = await storage.createUser(input);
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      }
    }
  });

  app.put(api.users.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.users.update.input.parse(req.body);
      const user = await storage.updateUser(Number(req.params.id), input);
      res.json(user);
    } catch (err) {
      res.status(400).json({ message: "Update failed" });
    }
  });

  // === Stats ===
  app.get(api.stats.dashboard.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const stats = await storage.getEmployeeStats();
    res.json({
      totalEmployees: stats.total,
      activeEmployees: stats.active,
      onLeaveEmployees: stats.onLeave,
      pendingEmployees: stats.pending,
    });
  });

  // === Attendance ===
  app.post(api.attendance.checkIn.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const record = await storage.checkIn(req.user!.id);
    res.json(record);
  });

  app.post(api.attendance.checkOut.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    // Find active checkin for today
    const today = new Date().toISOString().split('T')[0];
    const current = await storage.getAttendance(req.user!.id, today);
    if (!current) return res.status(404).json({ message: "No check-in found" });
    
    const record = await storage.checkOut(current.id);
    res.json(record);
  });

  app.get(api.attendance.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const list = await storage.listAttendance(req.query.userId ? Number(req.query.userId) : undefined);
    res.json(list);
  });

  // === Payroll ===
  app.get(api.payroll.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const list = await storage.listPayroll(req.query.userId ? Number(req.query.userId) : undefined);
    res.json(list);
  });

  app.post(api.payroll.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401); // Should be Admin only
    const record = await storage.createPayroll(req.body);
    res.status(201).json(record);
  });

  // === Tasks ===
  app.get(api.tasks.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const list = await storage.listTasks(req.query);
    res.json(list);
  });

  app.post(api.tasks.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const record = await storage.createTask({
      ...req.body,
      assignedBy: req.user!.id,
    });
    res.status(201).json(record);
  });

  app.put(api.tasks.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const record = await storage.updateTask(Number(req.params.id), req.body);
    res.json(record);
  });

  return httpServer;
}
